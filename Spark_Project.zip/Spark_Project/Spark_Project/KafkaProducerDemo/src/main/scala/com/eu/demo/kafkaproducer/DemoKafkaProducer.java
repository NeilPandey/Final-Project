package com.eu.demo.kafkaproducer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

/*
 * This program acts as the producer for the topic "salestopic"
 * in Kafka. You'll need to change the kafka parameters to
 * run it in different configurations 
 */
public class DemoKafkaProducer {

	public static int generateRandomInt(int min, int max) { // Function to
		// generate random integers
		Random rnd = new Random();
		int randomNum = rnd.nextInt((max - min) + 1) + min;
		return randomNum;
	}

	public static float generateRandomFloat() { // Function to
		// generate random floats
		Random rnd = new Random();
		return rnd.nextFloat();
	}

	public static void main(String[] args) {
		long events = Long.parseLong("10");

		Properties props = new Properties();
		props.put("metadata.broker.list", "localhost:9092");
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		props.put("partitioner.class", "com.eu.demo.kafkaproducer.CustomPartitioner");
		props.put("request.required.acks", "1");

		ProducerConfig config = new ProducerConfig(props);

		Producer<String, String> producer = new Producer<String, String>(config);

		for (long nEvents = 0; nEvents < events; nEvents++) {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date today = Calendar.getInstance().getTime();
			String reportDate = df.format(today);
			int storeId = 1000;
			int[] skus = {10,11,12,13,14,15,16};
			int skuId = skus[generateRandomInt(0, 5)];
			float amount = 10 * generateRandomFloat();
			String msg = reportDate + "," + storeId + "," + skuId + ","
					+ amount;
			KeyedMessage<String, String> data = new KeyedMessage<String, String>(
					"my_demo", msg);
			System.out.println(msg);
			producer.send(data);
		}
		producer.close();
	}
}

